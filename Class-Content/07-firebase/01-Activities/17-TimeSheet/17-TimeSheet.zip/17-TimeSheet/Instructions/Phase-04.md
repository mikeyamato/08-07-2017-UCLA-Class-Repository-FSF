# Employee Data Management - Datetime

## File

* *None*

## Instructions

* Use your newfound momentJS knowledge to calculate the number of months worked and, subsequently, the total amount billed.
